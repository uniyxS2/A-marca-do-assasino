import time
import os
import sys
import random
import re

#  CORES coloca assim ("eude viado",Nome da cor)

VERMELHO = "\033[31m"
CIANO = "\033[36m"
BRANCO = "\033[37m"
CINZA = "\033[90m"
RESET = "\033[0m"

LARGURA = 120


#  FUNCOES (Nao mecha nisso)

def limpar():
    os.system("cls" if os.name == "nt" else "clear")


# LINHA SUPERIOR E INFERIOR
def linha():
    print(CINZA + "█" + "═" * (LARGURA - 2) + "█" + RESET)


# MOLDURA DAS LATERAIS

# REMOVE CODIGOS ANSI DAS CORES
def limpar_ansi(texto):
    return re.sub(r'\033\[[0-9;]*m', '', texto)

# MOLDURA CENTRALIZADA CERTA
def moldura(texto="", cor=BRANCO):

    texto_limpo = limpar_ansi(texto)

    tamanho = len(texto_limpo)

    espaco = LARGURA - tamanho - 2

    if espaco < 0:
        espaco = 0

    esquerda = espaco // 2
    direita = espaco - esquerda

    print(
        CINZA + "█" + RESET
        + (" " * esquerda)
        + cor + texto + RESET
        + (" " * direita)
        + CINZA + "█" + RESET
    )

# FUNDO SOMBRIO
def fundo():

    simbolos = ["░", "▒", ".", "█", " "]

    linha_fundo = ""

    for _ in range(LARGURA - 2):

        if random.randint(0, 10) == 0:
            linha_fundo += random.choice(simbolos)
        else:
            linha_fundo += " "

    print(CINZA + "█" + linha_fundo + "█" + RESET)


# ANIMACAO das letras
def animar(texto, delay=0.05, cor=BRANCO):

    espacos = " " * ((LARGURA - len(texto)) // 2)

    sys.stdout.write(espacos)

    for letra in texto:
        sys.stdout.write(cor + letra + RESET)
        sys.stdout.flush()
        time.sleep(delay)

    print()


# GLITCH (nao toca nisso aqui)
def glitch(texto):

    chars = ["#", "@", "%", "&", "?"]

    for _ in range(3):

        limpar()

        linha()
        fundo()

        bugado = ""

        for letra in texto:

            if random.randint(0, 5) == 0:
                bugado += random.choice(chars)
            else:
                bugado += letra

        moldura(bugado, VERMELHO)

        fundo()
        linha()

        time.sleep(0.08)

# FRASES SOMBRIAS (nao uso)
frases = [
    "ELE ESTA OBSERVANDO",
    "NAO OLHE PARA TRAS",
    "VOCE ESCUTOU ISSO?",
    "CORRA",
    "NAO CONFIE NELES",
    "ALGO ESTA ERRADO",
]


def game_over():
    
    limpar()
    
    linha()
    
    moldura(VERMELHO + " ██████   █████  ███    ███ ███████ " + RESET)
    moldura(VERMELHO + "██       ██   ██ ████  ████ ██      " + RESET)
    moldura(VERMELHO + "██   ███ ███████ ██ ████ ██ █████   " + RESET)
    moldura(VERMELHO + "██    ██ ██   ██ ██  ██  ██ ██      " + RESET)
    moldura(VERMELHO + " ██████  ██   ██ ██      ██ ███████ " + RESET)
    
    moldura("")

    moldura(VERMELHO + " ██████  ██    ██ ███████ ██████   " + RESET)
    moldura(VERMELHO + "██    ██ ██    ██ ██      ██   ██  " + RESET)
    moldura(VERMELHO + "██    ██ ██    ██ █████   ██████   " + RESET)
    moldura(VERMELHO + "██    ██  ██  ██  ██      ██   ██  " + RESET)
    moldura(VERMELHO + " ██████    ████   ███████ ██   ██  " + RESET)

    linha()
    
    linha()
    moldura(VERMELHO + "VOCÊ MORREU" + RESET)
    linha()
    time.sleep(3)
    sys.exit()





def atoprologo():
    linha()
    moldura("Uma investigação marcada por assassinatos, segredos familiares e uma presença que parece acompanhar cada passo.")
    moldura("Documento confidencial — Prefeitura Municipal da Vila Ravenscroft. Ano 1300.")
    linha()
    
    input("aperte enter para continuar")
    
    moldura("Os investigadores designados por este documento estão autorizados a conduzir uma investigação sigilosa sobre os recentes assassinatos ocorridos na vila.")
    moldura("Devido ao medo entre os moradores e à falta de respostas das autoridades locais, a prefeitura exige discrição absoluta.")
    moldura("Assinado. Seja bem-vindo ao caso, senhor [Investigador].")
    linha()
    
    input("aperte enter para continuar")
    
    limpar()
    
def ato1():
    
    linha()
    moldura("O Investigador chega a uma pequena vila da Inglaterra após receber uma carta misteriosa.")
    moldura("Os moradores assustados indicam o delegado Edward Blackwood.")
    moldura("Ele responde às perguntas com uma pressa estranha, como se quisesse encerrar a conversa antes que ela avance demais.")
    moldura("Blackwood conta sobre três antigos casos envolvendo os primogênitos das famílias Whitmore, Lancaster e Hawthorne.")
    linha()
    
    
    
    linha()
    moldura("Então ele revela: Agora temos um novo caso. A jovem Emi foi encontrada morta esta manhã.")
    moldura("O Investigador segue para a mansão de Emi.")
    moldura("Na sala, encontram o corpo de Emi, e sua mãe Kaori — uma viajante do Oriente que se estabeleceu em Ravenscroft anos atrás, após se casar com um mercador local — chorando ao lado do corpo.")
    moldura("Marcas de sangue levam até a cozinha.")
    linha()
    
    input("aperte enter para continuar")
    limpar()
    

    while True:
        
        linha()
        moldura("[1] Examinar o corpo")
        moldura("[2] Conversar com Kaori")
        moldura("[3] Seguir as marcas de sangue")
        moldura("[4] Interrogar os criados da casa")
        moldura("[5] Continuar")
        linha()
        
        escolha = input(VERMELHO + "\n              >>> " + RESET)
            
        if escolha == "1":
        
            linha()
            moldura("Vocês encontram fragmentos de madeira, um tecido preto e um colar quebrado. O tempo gasto examinando o ")
            moldura("corpo permite que Kaori se recomponha — e feche a expressão antes que vocês possam falar com ela.")
            linha()
            
            input("aperte enter para continuar")
            limpar()
            
            
        elif escolha == "2":
        
            linha()
            moldura("Kaori revela: ""Demi dizia ouvir passos durante a noite. Ela acreditava que alguém vivia na mansão." "Ela confia em")
            moldura("vocês o suficiente para falar, mas o corpo de Emi fica sem exame — algum vestígio físico pode se perder quando ")
            moldura("os criados finalmente o cobrirem.")
            linha()
            
            input("aperte enter para continuar")
            limpar()
        
        elif escolha == "3":
        
            linha()
            moldura("As marcas terminam diante de um grande armário.")
            moldura("Há riscos recentes no chão. Kaori observa vocês em silêncio, ")
            moldura("sem que ninguém pergunte nada a ela.")
            linha()
            
            input("aperte enter para continuar")
            limpar()
    
        elif escolha == "4":
        
            linha()
            moldura("Os criados estão apavorados demais para falar com clareza,")
            moldura("mas um deles murmura que ouviu uma discussão na noite anterior.")
            moldura("Uma voz de homem. Não era da casa," "ele diz, antes de se calar.")
            linha()
            
            input("aperte enter para continuar")
            limpar()
            
        elif escolha == "5":
            break
        
            
    
        else:
            print("opcao invalida")
    
    limpar()
    
    linha()
    moldura("A porta dos fundos está entreaberta")
    linha()

    while True:
        
        linha()
        moldura("[1]  Vasculhar o jardim:")
        moldura("[2]  Examinar a cozinha novamente:")
        moldura("[3]  Continuar")
        linha()

        escolha2 = input(VERMELHO + "\n              >>> " + RESET)

        if escolha2 == "1":
            
            linha()
            moldura("o jardim, encontram uma adaga com a marca de assassino: um símbolo antigo gravado na lâmina.")
            moldura("Mas as pegadas ao redor foram apagadas pela chuva da manhã.")
            linha()
            
            input("aperte enter para continuar")
            limpar()
            
        elif escolha2 == "2":
            
            linha()
            moldura("Na cozinha encontram comida envenenada e uma nota.")
            moldura(" Na nota está escrito apenas um símbolo antigo.")
            moldura("O jardim, agora sob chuva, não será revisitado tão cedo.")
            linha()
            
            input("aperte enter para continuar")
            limpar()
            
        elif escolha2 == "3":
            break
        
        input("aperte enter para continuar")
        limpar()
        
        linha()
        moldura("Fim ato1")
        linha()

def ato2():
    
    linha()
    moldura("O Investigador passa dias investigando as famílias fundadoras.")
    moldura("Whitmore, Lancaster, Hawthorne... todos relacionados aos antigos assassinatos.")
    moldura("Todos perderam seus primogênitos sob circunstâncias misteriosas.")
    linha()
    
    linha()
    moldura("Kaori, grata pela discrição no dia da morte de Emi, oferece uma pista:")
    moldura("Procure primeiro os Lancaster. Emi tinha medo deles.")
    linha()
    
    input("aperte enter para continuar")
    
    linha()
    moldura("[1] Os Whitmore:")
    moldura("[2] Os Lancaster:")
    moldura("[3] Os Hawthorne")
    moldura("[4] Continuar")
    linha()
    
    escolha3 = input(VERMELHO + "\n              >>> " + RESET)
    
    while True:
        
        linha()
        moldura("[1] Os Whitmore:")
        moldura("[2] Os Lancaster:")
        moldura("[3] Os Hawthorne")
        moldura("[4] Continuar")
        linha()
        
        escolha3 = input(VERMELHO + "\n              >>> " + RESET)
        
        if escolha3 == 1:
            
            linha()
            moldura("Os Whitmore revelam um segredo famoso: o primogênito Samuel foi encontrado com a mesma marca de Emi.")
            moldura("Há trinta anos.")
            linha()
            
            input("aperte enter para continuar")
            limpar()
            
        elif escolha3 == "2":
            
            linha()
            moldura("Confrontados com o nome de Emi, os Lancaster ficam visivelmente nervosos.")
            moldura("Admitem que seu filho desapareceu misteriosamente, mas escondem algo mais — seus olhares se cruzam antes de responder.")
            linha()
            
            input("aperte enter para continuar")
            limpar()
            
        elif escolha3 == "3":
            
            linha()
            moldura("Os Hawthorne têm registros estranhos.")
            moldura("Seu primogênito Geoffrey foi encontrado em circunstâncias obscuras.")
            moldura("corpo foi rapidamente enterrado de noite.")
            linha()
            
            input("aperte enter para continuar")
            limpar()
    
        elif escolha3 == "4":
            break
    else:
        print("opcao invalida")
    
    input("aperte enter para continuar")
    limpar()
    
    linha()
    moldura("Reflexão sobre a teoria:")
    moldura("Serial killer tradicional → Você mantém a lógica investigativa. Isso soa bem diante do delegado, mas fecha sua mente para algumas das pistas mais estranhas que já reuniu.")
    moldura("As famílias se matando mutuamente → Você desconfia que há conflito entre as famílias. A teoria não convence ninguém na vila, e alguns moradores passam a evitar suas perguntas.")
    moldura("Algo sobrenatural → Você começa a questionar sua própria sanidade. Mas essa abertura mental também deixa você mais atento a detalhes que a lógica pura ignoraria.")
    linha()
    
    input("aperte enter para continuar")
    
    limpar()
    
    linha()
    moldura("fim ato2")
    linha()
    
def ato3():
    
    linha()
    moldura("Analisando as pistas, você descobre que todas as vítimas tinham uma coisa em comum.")
    moldura("Todas frequentavam uma antiga biblioteca privada da vila.")
    moldura("Uma biblioteca que ninguém sabe onde fica.")
    linha()
    
    
    linha()
    moldura("Margaret, grata por sua discrição sobre Samuel, oferece ajuda:")
    moldura("Os registros da família podem apontar um caminho mais rápido.")
    linha()
    
    input("aperte enter para continuar")
    limpar()
    
    while True:
        
        linha()
        moldura("[1]  Interrogar os moradores antigos ")
        moldura("[2]  Procurar registros públicos:")
        moldura("[3]  Rastrear os movimentos das vítimas:")
        moldura("[4]  Pedir acesso aos arquivos privados dos Whitmore")
        moldura("[5]  continuar")
        linha()
        
        escolha4 = input(VERMELHO + "\n              >>> " + RESET)
        
        if escolha4 == "1":
            
            linha()
            moldura("Um homem idoso revela informações cruciais.")
            moldura("A biblioteca fica escondida sob a torre da antiga prefeitura.")
            moldura("Ele avisa: ""Não vá sozinho de noite.")
            linha()
            
            input("aperte enter para continuar")
            limpar()
            
        elif escolha4 == "2":
            
            linha()
            moldura("Você encontra referências a uma ""Sala de Estudos Aurelius""em pergaminhos guardados há mais de cem anos, muito antes da fundação de Ravenscroft.")
            moldura("Aurelius parece ser o nome de alguém importante para a história.")
            moldura("Mas os registros não dizem onde essa sala está — só que existe.")
            linha()
            
            input("aperte enter para continuar")
            limpar()
            
        elif escolha4 == "3":
            
            linha()
            moldura("Você descobre que as vítimas saíram de suas casas por noites consecutivas.")
            moldura("Sempre em direção ao norte da vila.")
            moldura("Sempre retornando antes do amanhecer.")
            moldura("Até a última noite, quando não voltaram.")
            linha()
            
            input("aperte enter para continuar")
            limpar()
            
        elif escolha4 == "4":
            
            linha()
            moldura("Nos arquivos dos Whitmore, você encontra uma planta antiga da prefeitura com uma área marcada como ""selada por ordem da família")
            moldura("É exatamente sob a torre.")
            linha()
            
            input("aperte enter para continuar")
            limpar()
        
        elif escolha4 == "5":
            break
        
        input("aperte enter para continuar")
        limpar()
        
    else:
        print("opcao invalida")
            
    linha()
    moldura("juntando todas as informações leva você a torre")
    moldura("Fim ato3")
    linha()
    
    input("aperte enter para continuar")
    limpar()

    #fim ato3

def ato4():
    
    linha()
    moldura("Você chega à antiga prefeitura no meio da noite.")
    moldura("A estrutura está aparentemente abandonada.")
    moldura("Mas há sinais recentes de atividade.")
    linha()
    moldura("Graças ao mapa que já possui, você sabe exatamente onde ficam os pontos fracos da estrutura.")
    linha()
    
    input("aperte enter para continuar")
    limpar()
    
    while True:
        
        linha()
        moldura("[1]  Pela porta principal com força: ")
        moldura("[2]  Procurando entrada discreta")
        moldura("[3]  Esperando e observando")
        moldura("[4] Continuar")
        linha()
        
        escolha5 = input(VERMELHO + "\n              >>> " + RESET)
            
        if escolha5 == 1:
            
            linha()
            moldura("A porta cede facilmente.")
            moldura("Como se alguém quisesse que você entrasse.")
            moldura("O barulho ecoa — se havia alguém lá dentro, agora já sabe que você chegou.")
            linha()
            
            input("aperte enter para continuar")
            limpar()
            
    
        elif escolha5 == 2:
            
            linha()
            moldura("Você encontra uma janela destrancada.")
            moldura("Entra silenciosamente, mas perde um tempo precioso procurando o caminho certo lá dentro.")
            linha()
            
            input("aperte enter para continuar")
            limpar()
            
        elif escolha5 == 3:
            
            linha()
            moldura("Esperando nas sombras, você vê três pessoas encapuzadas entrarem pela torre.")
            moldura("Eles carregam velas e falam em sussurros.")
            moldura("Um deles manca ligeiramente ao subir os degraus — o mesmo jeito de andar que você notou em Blackwood.")
            moldura("Mas esperar tem um preço: o frio da noite cala fundo nos ossos.")
            linha()
            
            input("aperte enter para continuar")
            limpar()
                
        elif escolha5 == 4:
            break
        
        input("aperte enter para continuar")
        limpar()
        
    else:
        print("opcao invalida")
        
    linha()
    moldura("Escada em espiral descendo:")
    linha()
    
    while True:
        
        linha()
        moldura("[1]  Descer com cuidado: ")
        moldura("[2]  Procurar outros cômodos:")
        moldura("[3]  Deixar a torre e buscar ajuda:")
        moldura("[4]  Continuar")
        linha()
        
        escolha6 = input(VERMELHO + "\n              >>> " + RESET)
        
        if escolha6 == 1:
            
            linha()
            moldura("Você desce.")
            moldura("O ar fica mais frio a cada degrau.")
            moldura("No final da escada, há uma porta de madeira envelhecida.")
            moldura("Há luz vermelha saindo por baixo dela.")
            linha()
            
            input("aperte enter para continuar")
            limpar()
            
        elif escolha6 == 2:
            
            linha()
            moldura("Você explora os cômodos acima.")
            moldura("Encontra registros antigos sobre cerimônias e sacrifícios.")
            moldura("Mas o tempo gasto permite que quem está lá embaixo perceba sua presença.")
            linha()
            
            input("aperte enter para continuar")
            limpar()
            
        elif escolha6 == 3:
            
            linha()
            moldura("Você sai da torre questionando se deveria ter agido sozinho.")
            moldura("A noite passa sem incidente, mas o delegado Blackwood pergunta, no dia seguinte, por que você foi visto perto da prefeitura.")
            linha()
            
            input("aperte enter para continuar")
            limpar()
            
        elif escolha6 == 4:
            break
        
        input("aperte enter para continuar")
        limpar()
        
    linha()
    moldura("fim ato4")
    linha()
    

    #fim ato4

def ato5():
    
    linha()
    moldura("Você finalmente entra na câmara subterrânea.")
    moldura("É uma biblioteca, mas de natureza perturbadora.")
    moldura("As paredes estão cobertas de símbolos antigos.")
    moldura("Livros descrevem rituais esquecidos e segredos ancestrais.")
    linha()
    
    linha()
    moldura("[1]  Os Sacrifícios de Aurelius ")
    moldura("[2]  Diário pessoal envelhecido:")
    moldura("[3]  Grimório antigo:")
    moldura("[4]  Continuar ")
    linha()
    
    escolha7 = input(VERMELHO + "\n              >>> " + RESET)
    
    while True:
        
        linha()
        moldura("[1]  Os Sacrifícios de Aurelius ")
        moldura("[2]  Diário pessoal envelhecido:")
        moldura("[3]  Grimório antigo:")
        moldura("[4]  Continuar ")
        linha()
        
        escolha7 = input(VERMELHO + "\n              >>> " + RESET)
        
        if escolha7 == 1:
            
            limpar()
            
            linha()
            moldura("O livro descreve rituais de sacrifício realizados há séculos.")
            moldura("Aurelius era um mago que buscava imortalidade.")
            moldura("Ele acreditava que sacrifícios puros o mantinham vivo.")
            linha()
            
            input("aperte enter para continuar")
            limpar()
            
        elif escolha7 == 2:
            
            
            limpar()
            
            linha()
            moldura("O diário pertence a uma mulher que viveu na vila há mais de um século, muito antes do nascimento de Emi.")
            moldura("Ela descreve encontros com ""'O Guardião'"", uma figura encapuzada.")
            moldura("O Guardião a guiava em cerimônias noturnas.")
            linha()
            
            input("aperte enter para continuar")
            limpar()
        
        elif escolha7 == 3:
            
            limpar()
            
            linha()
            moldura("O grimório está escrito em uma língua antiga.")
            moldura("Mas você consegue traduzir algumas frases:")
            moldura("'Para manter a marca viva, novos sangues devem ser oferecidos.'")
            moldura("'A marca escolhe seus portadores através dos tempos.'")
            linha()
            
            input("aperte enter para continuar")
            limpar()
        
        elif escolha7 == 4:
            break
        
        input("aperte enter para continuar")
        limpar()
        
    else:
        print("opcao invalida")
            
    linha()
    moldura("*Porta oculta na biblioteca:*")
    linha()
    
    linha()
    moldura("[1]  Tentar abrir a porta: ")
    moldura("[2]  Procurar chave/mecanismo:")
    moldura("[3]  Sair para preparar expedição:")
    moldura("[4]  Continuar")
    linha()
    
    escolha8 = input(VERMELHO + "\n              >>> " + RESET)
    
    while True:
        
        if escolha8 == 1:
            linha()
            moldura("A porta não abre.")
            moldura("Mas você ouve passos se aproximando das escadas.")
            moldura("Você não está mais sozinho.")
            linha()
            
            input("aperte enter para continuar")
            limpar()
            
        elif escolha8 == 2:
            
            linha()
            moldura("Você procura sistematicamente e encontra uma chave antiga escondida em um compartimento secreto.")
            moldura("A porta se abre, revelando um corredor ainda mais escuro.")
            moldura("A busca cuidadosa, porém, consome tempo — e quem quer que tenha deixado a chave ali pode saber que ela sumiu.")
            linha()
            
            input("aperte enter para continuar")
            limpar()
            
        elif escolha8 == 3:
            
            linha()
            moldura("Você sai rapidamente da biblioteca, carregando alguns livros para análise futura.")
            moldura("É a escolha mais segura, mas a porta oculta continua sem resposta.")
            linha()
            
            input("aperte enter para continuar")
            limpar()
            
            
        elif escolha8 == 4:
            break
        
    linha()
    moldura("Fim ato5")
    linha()
    
def ato6():
    
    linha()
    moldura("Você retorna à mansão de Emi com seu conhecimento recém-adquirido.")
    moldura("Kaori o recebe, mas há algo diferente em seu olhar.")
    moldura("Ela sabe que você descobriu a verdade.")
    linha()
    
    linha()
    moldura("[1] Confrontar Kaori diretamente:  ")
    moldura("[2] Fingir ignorância e observar: ")
    moldura("[3]  Procurar evidências físicas::")
    moldura("[4] Pedir que Kaori conte a verdade, como aliada")
    moldura("[5]  Continuar")
    linha()
    
    escolha9 = input(VERMELHO + "\n              >>> " + RESET)
    
    while True:
        
        linha()
        moldura("[1] Confrontar Kaori diretamente:  ")
        moldura("[2] Fingir ignorância e observar: ")
        moldura("[3]  Procurar evidências físicas::")
        moldura("[4] Pedir que Kaori conte a verdade, como aliada")
        moldura("[5]  Continuar")
        linha()
        
        escolha9 = input(VERMELHO + "\n              >>> " + RESET)
        
    
        if escolha9 == 1:
            
            linha()
            moldura("Kaori admite tudo entre lágrimas.")
            moldura("Emi foi escolhida pela marca como sacrifício.")
            moldura("Kaori acreditava que sacrificá-la salvaria a vila.")
            linha()
            
            input("aperte enter para continuar")
            limpar()
            
        elif escolha9 == 2:
            
            linha()
            moldura("Você observa Kaori durante horas.")
            moldura("Ela começa a falar sozinha, mencionando A marca e O Guardião.")
            moldura("Ela descobre que você a está observando.")
            moldura("Kaori tenta fugir.")
            linha()
            
            input("aperte enter para continuar")
            limpar()
            
        elif escolha9 == 3:
            linha()
            moldura("Você encontra um altar oculto em um quarto secreto.")
            moldura("Nele estão símbolos idênticos aos da biblioteca.")
            moldura("E oferendas de sangue envelhecidas.")
            moldura("Kaori observa a distância, sem impedir — como se quisesse ser encontrada.")
            linha()
            
            input("aperte enter para continuar")
            limpar()
            
        elif escolha9 == 4:
            
            linha()
            moldura("Kaori chora ao contar tudo, aliviada por não precisar mais esconder o peso que carrega sozinha.")
            moldura("Eu não sabia como te contar sem que você me odiasse," "ela diz.")
            moldura("Ela promete ajudar a encontrar o resto do culto — de dentro.")
            linha()
            
            input("aperte enter para continuar")
            limpar()
            
        elif escolha9 == 5:
            break
    
    
    linha()
    moldura("fim ato 6")
    linha()
    
    input("aperte enter para continuar")

#fim ato 6

def ato7():
    
    linha()
    moldura("Meses se passaram desde suas descobertas.")
    moldura("Você continuou investigando o culto em segredo, reunindo aliados e evidências, mas o rastro esfriou.")
    moldura("Você acreditava ter perdido a trilha.")
    moldura("Mas agora uma nova vítima aparece.")
    moldura("Outro corpo com a marca.")
    moldura("E desta vez, é em uma mansão que você conhece bem.")
    linha()
    
    input("aperte enter para continuar")
    limpar()
    
    linha()
    moldura("Qual e a sua reacao")
    linha()
    
    linha()
    moldura("[1] Raiva e determinação ")
    moldura("[2] Desespero")
    moldura("[3] Suspeita de armadilha")
    moldura("[4]  Continuar")
    linha()
    
    escolha10 = input(VERMELHO + "\n              >>> " + RESET)
    
    if escolha10 == "1":
        
        limpar()
        
        linha()
        moldura("Você jura encontrar e destruir o culto de uma vez.")
        moldura("A determinação o cega para os riscos à sua frente.")
        linha()
        
        linha()
        moldura("Chegando na cena do crime voce você muito iritado anda para o portao dela la você encontra")
        linha()
        
        input("aperte enter para continuar")
        
        linha()
        moldura("[1] Mapa para o norte:")
        moldura("[2] Carta com o símbolo da marca")
        moldura("[3] Pegadas estranhas")
        moldura("[4]  Continuar")
        linha()
        
        escolha11 = input(VERMELHO + "\n              >>> " + RESET)
        
        while True:
            
            linha()
            moldura("[1] Mapa para o norte:")
            moldura("[2] Carta com o símbolo da marca")
            moldura("[3] Pegadas estranhas")
            moldura("[4]  Continuar")
            linha()
            
            escolha11 = input(VERMELHO + "\n              >>> " + RESET)
            
        
            if escolha11 == 1:
                
                limpar()
                
                linha()
                moldura("O mapa marca claramente a localização de uma estrutura antiga.")
                moldura("Uma abadia esquecida no coração da floresta.")
                linha()
                
                input("aperte enter para continuar")
                limpar()
                
            elif escolha11 == 2:
                
                linha()
                moldura("A carta é uma provocação:")
                moldura("Sua obsessão o levará até nós. A marca aguarda.")
                linha()
                
                input("aperte enter para continuar")
                limpar()
                
            elif escolha11 == 3:
                
                linha()
                moldura("As pegadas são humanoides, mas deformadas.")
                moldura("Como se a pessoa caminhasse de forma não natural.")
                linha()
                
                input("aperte enter para continuar")
                limpar()
                
            elif escolha11 == 4:
                break
            
            input("aperte enter para continuar")
            limpar()
            
        else:
            print("opcao invalida")
                   
                   
        linha()
        moldura("A casa explode repentinamente:")
        linha()
         
        linha()
        moldura("[1] Sair antes de cair:")
        moldura("[2] Ser derrubado pela explosão:")
        moldura("[3] Estar longe o suficiente")
        linha()
        
        escolha12 = input(VERMELHO + "\n              >>> " + RESET)
        
        if escolha12 == "1":
            
            limpar()
            
            linha()
            moldura("Você sai correndo, mas o fogo consome a prova.")
            moldura("As evidências que poderia ter reunido desaparecem.")
            linha()
            
            input("aperte enter para continuar")
            
            linha()
            moldura("Uma coisa é clara: o culto quer que você os encontre.")
            moldura("E ele quer que você vá para aquela abadia.")
            moldura("A questão é: você terá forças para enfrentar o que o aguarda lá?")
            linha()
            
        elif escolha12 == "2":
            
            limpar()
            
            linha()
            moldura("Você passa horas inconsciente.")
            moldura("Quando acorda no hospital, já é noite.")
            moldura("As provas se foram.")
            linha()
            
            input("aperte enter para continuar")
            
            linha()
            moldura("Uma coisa é clara: o culto quer que você os encontre.")
            moldura("E ele quer que você vá para aquela abadia.")
            moldura("A questão é: você terá forças para enfrentar o que o aguarda lá?")
            linha()
            
            linha()
            moldura("fim 2 ato7")
            linha()
            
        elif escolha12 == "3":
            
            limpar()
            
            linha()
            moldura("Você consegue documentar provas antes da explosão.")
            moldura("O conhecimento que você reúne será crucial — mas a distância também significa que não conseguiu ajudar quem estava lá dentro.")
            linha()
            
            input("aperte enter para continuar")
    
            linha()
            moldura("Uma coisa é clara: o culto quer que você os encontre.")
            moldura("E ele quer que você vá para aquela abadia.")
            moldura("A questão é: você terá forças para enfrentar o que o aguarda lá?")
            linha()
            
            linha()
            moldura("fim 3 ato7")
            linha()
            
        else:
            print("opcao invalida")
    
    
    elif escolha10 == 2:
        
        linha()
        moldura("O medo toma conta de você, mas você sabe qual e o unico caminho")
        moldura("Mesmo com medo você nao tem outra opcao")
        moldura("chegando no portao você se deparra com algumas coisa")
        linha()
        
        input("aperte enter para continuar")
        limpar()
        
        linha()
        moldura("[1] Mapa para o norte:")
        moldura("[2] Carta com o símbolo da marca")
        moldura("[3] Pegadas estranhas")
        moldura("[4]  Continuar")
        linha()
        
        escolha11 = input(VERMELHO + "\n              >>> " + RESET)
        
        while True:
            
            linha()
            moldura("[1] Mapa para o norte:")
            moldura("[2] Carta com o símbolo da marca")
            moldura("[3] Pegadas estranhas")
            moldura("[4]  Continuar")
            linha()
        
            escolha11 = input(VERMELHO + "\n              >>> " + RESET)
                
                
            if escolha11 == 1:
                    
                    linha()
                    moldura("O mapa marca claramente a localização de uma estrutura antiga.")
                    moldura("Uma abadia esquecida no coração da floresta.")
                    linha()
                    
                    input("aperte enter para continuar")
                    limpar()
                    
            elif escolha11 == 2:
                    
                    linha()
                    moldura("A carta é uma provocação:")
                    moldura("Sua obsessão o levará até nós. A marca aguarda.")
                    linha()
                    
                    input("aperte enter para continuar")
                    limpar()
                    
            elif escolha11 == 3:
                    
                    linha()
                    moldura("As pegadas são humanoides, mas deformadas.")
                    moldura("Como se a pessoa caminhasse de forma não natural.")
                    linha()
                    
                    input("aperte enter para continuar")
                    limpar()
                    
            elif escolha11 == 4:
                    break
                
                    input("aperte enter para continuar")
                    limpar()
                a
        else:
            print("opcao invalida")
            
            
        linha()
        moldura("A casa explode repentinamente:")
        linha()
        
        linha()
        moldura("[1] Sair antes de cair:")
        moldura("[2] Ser derrubado pela explosão:")
        moldura("[3] Estar longe o suficiente")
        linha()
        
        escolha14 = input(VERMELHO + "\n              >>> " + RESET)
        
        if escolha14 == "1":
            
            limpar()
            input("aperte enter para continuar")
            
            
            linha()
            moldura("Você sai correndo, mas o fogo consome a prova.")
            moldura("As evidências que poderia ter reunido desaparecem.")
            linha()
            
            input("aperte enter para continuar")
            
            linha()
            moldura("Uma coisa é clara: o culto quer que você os encontre.")
            moldura("E ele quer que você vá para aquela abadia.")
            moldura("A questão é: você terá forças para enfrentar o que o aguarda lá?")
            linha()
            
        elif escolha14 == "2":
            
            linha()
            moldura("Você passa horas inconsciente.")
            moldura("Quando acorda no hospital, já é noite.")
            moldura("As provas se foram.")
            linha()
            
            input("aperte enter para continuar")
            
            linha()
            moldura("Uma coisa é clara: o culto quer que você os encontre.")
            moldura("E ele quer que você vá para aquela abadia.")
            moldura("A questão é: você terá forças para enfrentar o que o aguarda lá?")
            linha()
            
            linha()
            moldura("fim 2 ato7")
            linha()
            
        elif escolha14 == "3":
            
            linha()
            moldura("Você consegue documentar provas antes da explosão.")
            moldura("O conhecimento que você reúne será crucial — mas a distância também significa que não conseguiu ajudar quem estava lá dentro.")
            linha()
            
            input("aperte enter para continuar")
    
            linha()
            moldura("Uma coisa é clara: o culto quer que você os encontre.")
            moldura("E ele quer que você vá para aquela abadia.")
            moldura("A questão é: você terá forças para enfrentar o que o aguarda lá?")
            linha()
            
            linha()
            moldura("fim 3 ato7")
            linha()
        
        
        elif escolha10 == "3":
        
            linha()
            moldura("Sua intuição pode salvá-lo — mas a hesitação também tem um custo.")
            moldura("você chega depois de um tempo mas percebe algumas coisa para investigar")
            linha()
            
            input("aperte enter para continuar")
            limpar()
            
            linha()
            moldura("[1] Mapa para o norte:")
            moldura("[2] Carta com o símbolo da marca")
            moldura("[3] Pegadas estranhas")
            moldura("[4]  Continuar")
            linha()
        
        escolha15 = input(VERMELHO + "\n              >>> " + RESET)
        
        while True:
            
            
            
            linha()
            moldura("[1] Mapa para o norte:")
            moldura("[2] Carta com o símbolo da marca")
            moldura("[3] Pegadas estranhas")
            moldura("[4]  Continuar")
            linha()
            
            escolha15 = input(VERMELHO + "\n              >>> " + RESET)
                
            if escolha15 == "1":
                    
                    linha()
                    moldura("O mapa marca claramente a localização de uma estrutura antiga.")
                    moldura("Uma abadia esquecida no coração da floresta.")
                    linha()
                    
                    input("aperte enter para continuar")
                    limpar()
                    
            elif escolha15 == "2":
                    
                    linha()
                    moldura("A carta é uma provocação:")
                    moldura("Sua obsessão o levará até nós. A marca aguarda.")
                    linha()
                    
                    input("aperte enter para continuar")
                    limpar()
                    
            elif escolha15 == "3":
                    
                    linha()
                    moldura("As pegadas são humanoides, mas deformadas.")
                    moldura("Como se a pessoa caminhasse de forma não natural.")
                    linha()
                    
                    input("aperte enter para continuar")
                    limpar()
                    
            elif escolha15 == "4":
                    
                    break
                
                    input("aperte enter para continuar")
                    limpar()
                
                
        else:
            print("opcao invalida")
                    
        linha()
        moldura("A casa explode repentinamente:")
        linha()
        
        linha()
        moldura("[1] Sair antes de cair:")
        moldura("[2] Ser derrubado pela explosão:")
        moldura("[3] Estar longe o suficiente")
        linha()
        
        escolha14 = input(VERMELHO + "\n              >>> " + RESET)
        
        
        if escolha14 == "1":
            
            linha()
            moldura("Você sai correndo, mas o fogo consome a prova.")
            moldura("As evidências que poderia ter reunido desaparecem.")
            linha()
            
            input("aperte enter para continuar")
            
            linha()
            moldura("Uma coisa é clara: o culto quer que você os encontre.")
            moldura("E ele quer que você vá para aquela abadia.")
            moldura("A questão é: você terá forças para enfrentar o que o aguarda lá?")
            linha()
            
        elif escolha14 == "2":
            
            linha()
            moldura("Você passa horas inconsciente.")
            moldura("Quando acorda no hospital, já é noite.")
            moldura("As provas se foram.")
            linha()
            
            input("aperte enter para continuar")
            
            linha()
            moldura("Uma coisa é clara: o culto quer que você os encontre.")
            moldura("E ele quer que você vá para aquela abadia.")
            moldura("A questão é: você terá forças para enfrentar o que o aguarda lá?")
            linha()
            
            linha()
            moldura("fim 2 ato7")
            linha()
            
        elif escolha14 == "3":
            
            linha()
            moldura("Você consegue documentar provas antes da explosão.")
            moldura("O conhecimento que você reúne será crucial — mas a distância também significa que não conseguiu ajudar quem estava lá dentro.")
            linha()
            
            input("aperte enter para continuar")
    
            linha()
            moldura("Uma coisa é clara: o culto quer que você os encontre.")
            moldura("E ele quer que você vá para aquela abadia.")
            moldura("A questão é: você terá forças para enfrentar o que o aguarda lá?")
            linha()
            
            linha()
            moldura("fim 3 ato7")
            linha()


    
    


# PRIMEIRA TELA

def bem_vindo():

    limpar()

    linha()

    fundo()

    moldura("██████╗ ███████╗███╗   ███╗", CIANO)
    moldura("██╔══██╗██╔════╝████╗ ████║", CIANO)
    moldura("██████╔╝█████╗  ██╔████╔██║", CIANO)
    moldura("██╔══██╗██╔══╝  ██║╚██╔╝██║", CIANO)
    moldura("██████╔╝███████╗██║ ╚═╝ ██║", CIANO)
    moldura("╚═════╝ ╚══════╝╚═╝     ╚═╝", CIANO)

    moldura()

    moldura("██╗   ██╗██╗███╗   ██╗██████╗  ██████╗ ", CIANO)
    moldura("██║   ██║██║████╗  ██║██╔══██╗██╔═══██╗", CIANO)
    moldura("██║   ██║██║██╔██╗ ██║██║  ██║██║   ██║", CIANO)
    moldura("╚██╗ ██╔╝██║██║╚██╗██║██║  ██║██║   ██║", CIANO)
    moldura(" ╚████╔╝ ██║██║ ╚████║██████╔╝╚██████╔╝", CIANO)
    moldura("  ╚═══╝  ╚═╝╚═╝  ╚═══╝╚═════╝  ╚═════╝ ", CIANO)
    
    moldura()
    
    moldura(" █████╗  ██████╗          ██╗ ██████╗  ██████╗  ██████╗ ", CIANO)
    moldura("██╔══██╗██╔═══██╗         ██║██╔═══██╗██╔════╝ ██╔═══██╗", CIANO)
    moldura("███████║██║   ██║         ██║██║   ██║██║  ███╗██║   ██║", CIANO)
    moldura("██╔══██║██║   ██║    ██   ██║██║   ██║██║   ██║██║   ██║", CIANO)
    moldura("██║  ██║╚██████╔╝    ╚█████╔╝╚██████╔╝╚██████╔╝╚██████╔╝", CIANO)
    moldura("╚═╝  ╚═╝ ╚═════╝      ╚════╝  ╚═════╝  ╚═════╝  ╚═════╝ ", CIANO)

    fundo()

    linha()

    time.sleep(3)


#  TITULO

def titulo():

    glitch("A MARCA DO ASSASSINO")

    limpar()

    linha()

    fundo()

    moldura(" █████╗ ", VERMELHO)
    moldura("██╔══██╗", VERMELHO)
    moldura("███████║", VERMELHO)
    moldura("██╔══██║", VERMELHO)
    moldura("██║  ██║", VERMELHO)

    moldura()

    moldura("███╗   ███╗ █████╗ ██████╗  ██████╗ █████╗ ", VERMELHO)
    moldura("████╗ ████║██╔══██╗██╔══██╗██╔════╝██╔══██╗", VERMELHO)
    moldura("██╔████╔██║███████║██████╔╝██║     ███████║", VERMELHO)
    moldura("██║╚██╔╝██║██╔══██║██╔══██╗██║     ██╔══██║", VERMELHO)
    moldura("██║ ╚═╝ ██║██║  ██║██║  ██║╚██████╗██║  ██║", VERMELHO)
    
    moldura()
    
    moldura("██████╗  ██████╗ ", VERMELHO)
    moldura("██╔══██╗██╔═══██╗", VERMELHO)
    moldura("██║  ██║██║   ██║", VERMELHO)
    moldura("██║  ██║██║   ██║", VERMELHO)
    moldura("██████╔╝╚██████╔╝", VERMELHO)
    moldura("╚═════╝  ╚═════╝ ", VERMELHO)
    
    moldura()
    
    moldura("█████╗ ███████╗███████╗ █████╗ ███████╗███████╗██╗███╗   ██╗ ██████╗ ", VERMELHO)
    moldura("██╔══██╗██╔════╝██╔════╝██╔══██╗██╔════╝██╔════╝██║████╗  ██║██╔═══██╗", VERMELHO)
    moldura("███████║███████╗███████╗███████║███████╗███████╗██║██╔██╗ ██║██║   ██║", VERMELHO)
    moldura("██╔══██║╚════██║╚════██║██╔══██║╚════██║╚════██║██║██║╚██╗██║██║   ██║", VERMELHO)
    moldura("██║  ██║███████║███████║██║  ██║███████║███████║██║██║ ╚████║╚██████╔╝", VERMELHO)
    
    moldura()

    moldura()

    moldura()

    moldura("PRODUZIDO POR 2D", BRANCO)

    fundo()

    linha()

    time.sleep(3)


# MENU

def menu():

    while True:

        limpar()

        linha()

        fundo()

        moldura(" █████╗ ", VERMELHO)
        moldura("██╔══██╗", VERMELHO)
        moldura("███████║", VERMELHO)
        moldura("██╔══██║", VERMELHO)
        moldura("██║  ██║", VERMELHO)

        moldura()
        
        moldura("███╗   ███╗ █████╗ ██████╗  ██████╗ █████╗ ", VERMELHO)
        moldura("████╗ ████║██╔══██╗██╔══██╗██╔════╝██╔══██╗", VERMELHO)
        moldura("██╔████╔██║███████║██████╔╝██║     ███████║", VERMELHO)
        moldura("██║╚██╔╝██║██╔══██║██╔══██╗██║     ██╔══██║", VERMELHO)
        moldura("██║ ╚═╝ ██║██║  ██║██║  ██║╚██████╗██║  ██║", VERMELHO)
        
        moldura()
        
        moldura("██████╗  ██████╗ ", VERMELHO)
        moldura("██╔══██╗██╔═══██╗", VERMELHO)
        moldura("██║  ██║██║   ██║", VERMELHO)
        moldura("██║  ██║██║   ██║", VERMELHO)
        moldura("██████╔╝╚██████╔╝", VERMELHO)
        moldura("╚═════╝  ╚═════╝ ", VERMELHO)
        
        moldura()
        
        moldura(" █████╗ ███████╗███████╗ █████╗ ███████╗███████╗██╗███╗   ██╗ ██████╗ ", VERMELHO)
        moldura("██╔══██╗██╔════╝██╔════╝██╔══██╗██╔════╝██╔════╝██║████╗  ██║██╔═══██╗", VERMELHO)
        moldura("███████║███████╗███████╗███████║███████╗███████╗██║██╔██╗ ██║██║   ██║", VERMELHO)
        moldura("██╔══██║╚════██║╚════██║██╔══██║╚════██║╚════██║██║██║╚██╗██║██║   ██║", VERMELHO)
        moldura("██║  ██║███████║███████║██║  ██║███████║███████║██║██║ ╚████║╚██████╔╝", VERMELHO)

        moldura()

        moldura(random.choice(frases), CINZA)

        moldura()

        moldura("[ 1 ] JOGAR", BRANCO)
        moldura("[ 2 ] TUTORIAL", BRANCO)
        moldura("[ 3 ] SAIR", BRANCO)

        fundo()

        linha()

        escolha = input(VERMELHO + "\n              >>> " + RESET)

#JOGAR

        if escolha == "1":

            for i in range(0, 101, 10):

                limpar()

                linha()

                fundo()

                moldura("CARREGANDO...", VERMELHO)

                moldura(f"{i}%", BRANCO)

                fundo()

                linha()

                time.sleep(0.2)

            print(VERMELHO + "\n              O JOGO COMECOU..." + RESET)

            time.sleep(2)
            
            atoprologo()
            
            ato1()
            
            ato2()
            
            ato3()
            
            ato4()
            
            ato5()
            
            ato5()
            
            ato6()
            
            ato7()

        # TUTORIAl

        elif escolha == "2":

            limpar()

            linha()

            fundo()

            moldura("TUTORIAL", CIANO)

            moldura()

            moldura("EUde viado", BRANCO)
            moldura("tutorial nao completo", BRANCO)

            moldura()

            moldura("PRESSIONE ENTER PARA VOLTAR", CINZA)

            fundo()

            linha()

            input()

        # SAIR

        elif escolha == "3":

            limpar()

            linha()

            fundo()

            moldura("ENCERRANDO SISTEMA...", VERMELHO)

            fundo()

            linha()

            time.sleep(2)

            sys.exit()

        #  ERRO

        else:

            print(VERMELHO + "\n              OPCAO INVALIDA!" + RESET)

            time.sleep(2)


#  INICIO

bem_vindo()

titulo()

menu()